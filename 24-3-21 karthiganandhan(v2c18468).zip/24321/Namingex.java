class Namingex extends Thread
{  
 public void run()
 {  
	 /*for(int i=0;i<5;i++)
	 {
		 System.out.println(i);
	 }*/
	 System.out.println(Thread.currentThread().getName()+"ID:"+Thread.currentThread().getId());  
 }  
 public static void main(String args[])
 {  
	 Namingex t1=new Namingex();  
	 Namingex t2=new Namingex();  
  t1.setName("first");
  t2.setName("second");

  t1.start();  
  t2.start();  
  //t1.run();//doesnt run simultaneously
  //t1.start()//exception
 }  
}  