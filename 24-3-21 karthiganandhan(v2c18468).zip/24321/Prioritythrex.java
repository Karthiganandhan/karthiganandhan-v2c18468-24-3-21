//checking priority and naming thread


class Prioritythrex extends Thread
{  
 public void run()
 {  
    
 
   
   
   System.out.println("running thread name is in run method:"+Thread.currentThread().getName()+"id: "+Thread.currentThread().getId());
   System.out.println("running thread priority is:"+Thread.currentThread().getPriority());
 
 }  
 public static void main(String args[])
 {  
	 Prioritythrex t1=new Prioritythrex();  
	 Prioritythrex t2=new Prioritythrex();  
	 Prioritythrex t3=new Prioritythrex();  
  t1.setPriority(Thread.MIN_PRIORITY);  
  t2.setPriority(Thread.MAX_PRIORITY); 
  t3.setPriority(Thread.NORM_PRIORITY);  
  t1.start();  
  t2.start();
  t3.start();
  t1.setName("First one");
  t2.setName("Second one");
  t3.setName("third");
  System.out.println("running thread name is in main:"+Thread.currentThread().getName());  
  System.out.println("After change the thread name is:"+t1.getName()+"second: "+t2.getName()+""+t3.getName());  
  System.out.println("After change the thread ID is:"+t1.getId()+"second: "+t2.getId()+""+t3.getId());

 }  
}     